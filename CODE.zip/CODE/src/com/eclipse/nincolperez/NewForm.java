/**
 * 
 */
package com.eclipse.nincolperez;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * @author nep00
 *
 */
public class NewForm {

	public NewForm() {

	}

	protected static  String courseName = "";
	protected static  int numOfCategories = 0;

	protected static String category = "";
	protected static int categoryValue = 0;

	protected static String [] categoryNames = null;
	protected static int[] categoryValues = null;

	protected static TextField categoryName = null;
	protected static TextField value = null;

	static Text warning = new Text();


	//COUNTER Variables
	protected static int i = 0;							//Loop counter
	protected static int arrayCounter = 0 ;				//Array counter
	protected static int categoryCounter = 0;				//category counter
	protected static int gridRowCounter = 0;
	protected static int valuesSum = 0;

	//Stage
	protected static Stage newFormStage = new Stage();

	static int vFposition = 0;

	public static  void DisplayForm() throws Exception {	
		
		StackPane big = new StackPane();
		big.setAlignment(Pos.TOP_CENTER);
		
		
		//Creating the main pane
		GridPane grid = new GridPane();
		grid.setAlignment(Pos.TOP_CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(20, 20, 20, 20));

		//Creating text, labels and text fields
		Text scenetitle = new Text("Grades up to date");
		scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));
		grid.add(scenetitle, 0, gridRowCounter, 2, 1);
		gridRowCounter++;

		Label course = new Label("Course Name:");
		grid.add(course, 0, gridRowCounter);
		TextField name = new TextField();
		grid.add(name, 1, gridRowCounter);

		//This counter will keep up with the grid row count to assign the correct row
		gridRowCounter++;

		Label categories = new Label("# of grading Categories:");
		grid.add(categories, 0, gridRowCounter);		
		TextField nC = new TextField();
		nC.setPromptText("Enter Valid Interger");	
		grid.add(nC, 1, gridRowCounter);
		gridRowCounter++;

		//Arrays needed to dynamically create Labels and TextField objects
		Label categoryLabels [] = new Label[15];
		TextField textField[] = new TextField[15];
		Label valueLabels [] = new Label[15];
		TextField valuesField [] = new TextField[15];

		Label addCategory = new Label("Add grading category");
		grid.add(addCategory, 0, gridRowCounter);
		Button add = new Button("Add");
		//add.setDisable(true);
		grid.add(add, 1, gridRowCounter);

		//This button will be located at the end of the grid
		Button reviewData = new Button("Review");
		reviewData.setDisable(true);
		grid.add(reviewData, 2, 5);
		gridRowCounter++;

		/**
		 * The following are lambdas that control action events in the text fields and buttons
		 */
		name.setOnAction(e-> {					
			if (name.getText().isEmpty())    { 				
				textFieldWarning(name);
				add.setDisable(true);
			}
			else {
				removeWarning(name);
				courseName = name.getText();
				add.setDisable(false);
			}		
			nC.requestFocus();
			//TESTING with print statement
			System.out.println(courseName);
		});	

		nC.setOnAction(e -> {	
			if (nC.getText().isEmpty() || (!isNumericInt(nC)))  {
				nC.clear();
				textFieldWarning(nC);
				add.setDisable(true);
				name.requestFocus();
			}					
			else {
				removeWarning(nC);
				numOfCategories = Integer.parseInt(nC.getText());
				categoryNames = new String[numOfCategories];
				categoryValues = new int[numOfCategories];
				add.setDisable(false);
			}
			//TEST PRINT STATEMENT
			System.out.println(numOfCategories);
		});

		// ADD BUTTON
		add.setOnAction(e -> {	
			category = null;
			categoryValue = 0;

			if(courseName == null ) {
				pressEnterWarning(name, add);
				nC.requestFocus();
				warning.setText("Press Enter key to save");
				grid.add(warning, 2, 1);
			}
			else if(numOfCategories == 0) {
				pressEnterWarning(nC, add);
				warning.setText("Press Enter key to save");
				grid.add(warning, 2, 2);				
			}

			else {
				warning.setText("OK");
				add.setDisable(false);			
				categoryCounter++;					
				//Creating new labels and fields dynamically and adding them to the form grid.
				categoryLabels[i] = new Label("Category Name");
				valueLabels[i] = new Label("Category Value");
				textField[i] = new TextField() ;
				valuesField[i] = new TextField();


				//Adding category label and field to grid
				grid.add(categoryLabels[i], 0, gridRowCounter);			
				grid.add(textField[i], 1, gridRowCounter);
				int tFposition = gridRowCounter;	//Counter tracks the position of the text fields in the grid
				textField[i].requestFocus();
				//Increase the counter to property locate the next set of labels and fields					
				gridRowCounter ++;
				grid.add(valueLabels[i], 0, (gridRowCounter));
				grid.add(valuesField[i], 1, gridRowCounter);
				vFposition = gridRowCounter;	//Counter tracks the position of the value fields in the grid
				//Increase the counter to property locate the next set of labels and fields	
				gridRowCounter ++;
				
				

				//Disable the add category button until it has been confirm that all previous data is valid
				//and also that another category needs to be added
				add.setDisable(true);

				//Lambdas that control the behavior of the text fieldS and value fields. These will also include
				//logic to validate user's input.
				textField[i].setOnAction(t-> {

					if(textField[i].getText().isEmpty()){
						valuesField[i].requestFocus();
						textFieldWarning(textField[i]);						
					}
					else {						
						removeWarning(textField[i]);
						category = textField[i].getText();
						System.out.println(category);	
						categoryNames[arrayCounter] = category;
						valuesField[i].requestFocus();
						if (categoryCounter < numOfCategories && category != null && categoryValue != 0) {
							add.setDisable(false);
						}

						else {
							add.setDisable(true);
							reviewData.setDisable(true);
						}
					}
					valuesField[i].requestFocus();

				});

				valuesField[i].setOnAction(v -> {	
					if (valuesField[i].getText().isEmpty() || (!isNumericInt(valuesField[i]))) { 
						valuesField[i].clear();
						textField[i].requestFocus();
						textFieldWarning(valuesField[i]);
						valuesField[i].getText();
					}

					else if (category == null) {
						reviewData.setDisable(true);
						valuesField[i].requestFocus();
						warning.setText("Press Enter key to save");
						grid.add(warning, 2, tFposition);
						add.setDisable(true);
					}


					else {
						removeWarning(textField[i]);
						categoryValue = Integer.parseInt(valuesField[i].getText());
						valuesSum += categoryValue; //ADDING UP THE CATEGORY Values
						System.out.println(categoryValue);
						if (categoryValue == 0) {
							textField[i].requestFocus();
							warning.setText("Press Enter key to save");
							grid.add(warning, 2, vFposition);
							add.setDisable(true);
						}
						else {
							removeWarning(valuesField[i]);
							warning.setText("OK");
							categoryValues[arrayCounter] = categoryValue;
							arrayCounter++;
							i++;
						}
					}

					if (categoryCounter < numOfCategories && category != null && categoryValue != 0) {
						add.setDisable(false);
					}
					else if(categoryCounter >= numOfCategories && category != null && categoryValue != 0) {
						reviewData.setDisable(false);
					}

					else if (category == null){
						//add.setDisable(true);
						reviewData.setDisable(true);
					}


				});

			}
			//if (category == null)
			//reviewData.setDisable(true);
		});

		reviewData.setOnAction(e -> {	

			System.out.println(valuesSum);
			if(valuesSum == 100) {
				FormConfirmation.confirmInput();
			}
			else  {
				reviewData.setDisable(true);
				valuesSum = 0;
				categoryValue =0;
				categoryValues = null;
				categoryValues = new int[numOfCategories];
				i = 0;
				arrayCounter = 0;
				
				for ( int y = 0 ; y < numOfCategories; y++ )
				{
					valuesField[y].clear();
					valuesField[y].setPromptText("SUM must equal 100");
					valuesField[y].setStyle("-fx-prompt-text-fill: red");
				}
				
				for ( int z = 0 ; z <= numOfCategories; z++ ) {
				valuesField[i].requestFocus();
				valuesField[i].setOnAction (n -> {
					categoryValue = Integer.parseInt(valuesField[i].getText());
					valuesSum += categoryValue; //ADDING UP THE CATEGORY Values
					System.out.println(categoryValue);					
					categoryValues[arrayCounter] = categoryValue;
					arrayCounter++;
					i++;
					
				});
				}
					if(valuesSum == 100) {
						reviewData.setDisable(false);
						FormConfirmation.confirmInput();
					}
														
			}	
		});

		// Creating scenes and placing grids inside these scenes.
		Scene scene = new Scene(grid, 500, 550);
		newFormStage.setTitle("Grades up to Date"); // Set the stage title
		newFormStage.setScene(scene); // Place the scene in the stage
		//primaryStage.setFullScreen(true);
		newFormStage.show(); // Display the stage
	}

	//INPUT VALIDATION METHODS-----------------------------------------------------------------------------------
	public static void textFieldWarning(TextField t) {
		t.setStyle("-fx-prompt-text-fill: blue");
		t.setStyle("-fx-text-box-border: red");
		t.setPromptText("ENTER VALID INPUT");
	}

	public static void removeWarning(TextField t) {
		t.setStyle("-fx-text-box-border: green");		
	}

	public static void pressEnterWarning(TextField t, Button b) {
		t.setStyle("-fx-text-box-border: red");
		//t.setPromptText("ENTER VALID INPUT");
		b.setDisable(true);
	}

	public static boolean isNumericInt(TextField n) {
		try {
			int in = Integer.parseInt(n.getText());
		} catch (NumberFormatException | NullPointerException nfe) {
			return false;
		}				
		return true;
	}

	public static boolean isNumericDouble(TextField n) {
		try {
			double d = Double.parseDouble(n.getText());
		} catch (NumberFormatException | NullPointerException dfe) {
			return false;
		}				
		return true;
	}


	public static void resetAll() {
		courseName = "";
		numOfCategories = 0;

		category = "";
		categoryValue = 0;

		categoryNames = null;
		categoryValues = null;

		categoryName = null;
		value = null;

		//COUNTER Variables
		i = 0;							
		arrayCounter = 0 ;				
		categoryCounter = 0;		
		gridRowCounter = 0;	
		valuesSum = 0;
	}

	//-----------------------------------------------------------------------------------------------------------

	//ACCESSORS(Getters)
	public static String getCourseName() {
		return courseName;
	}

	public static Integer getNumOfCategories() {
		return numOfCategories;
	}

	//Use for testing
	public static void printCategoriesName () {
		for (int j = 0; j < categoryNames.length; j++) {
			System.out.println(categoryNames[j] + " ");
		}		
	}

	public static void getCategorieValue() {
		for (int j = 0; j < categoryValues.length; j++) {
			System.out.println(categoryValues[j] + " ");
		}	
	}
}
