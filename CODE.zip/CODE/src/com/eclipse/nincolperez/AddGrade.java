package com.eclipse.nincolperez;

import java.sql.SQLException;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class AddGrade extends NewForm{
	public AddGrade () {
	}
	protected static String courseName;
	protected static String categoryName;
	protected static double grade;
	protected static Stage addGradeStage = new Stage();

	public static void enterGrade() throws Exception {
		//Creating stage


		//Creating main stack pane and inner Vbox pane
		StackPane grades = new StackPane();
		grades.setAlignment(Pos.TOP_CENTER);
		VBox box = new VBox();
		box.setAlignment(Pos.TOP_CENTER);
		box.setPadding(new Insets(20, 20, 20, 20));
		box.setSpacing(20);

		

		//Creating controls: Combo Boxes and Text fields
		ComboBox<String> courseOption = new ComboBox();
		ComboBox<String> categoryOption = new ComboBox();
		TextField enterGrade = new TextField();
		Button review = new Button("Review");
		review.setDisable(true);

		//DEVELOPING CONTROLS
		HBox courseInnerBox = new HBox();
		courseInnerBox.setSpacing(10);
		Label courseLabel = new Label("Select course name");
		courseLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, 16));
		courseInnerBox.getChildren().addAll(courseLabel, courseOption);

		HBox categoryInnerBox = new HBox();
		categoryInnerBox.setSpacing(10);
		Label categoryLabel = new Label("Select grading category");
		categoryLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, 16));
		categoryInnerBox.getChildren().addAll(categoryLabel, categoryOption);

		GridPane textFieldInnerBox = new GridPane();
		Label textF = new Label("Enter Grade");
		textF.setFont(Font.font("Times New Roman", FontWeight.BOLD, 16));
		textFieldInnerBox.add(textF, 0, 1);
		TextField gradeTextField = new TextField();
		textFieldInnerBox.add(gradeTextField, 1, 1);
		textFieldInnerBox.setAlignment(Pos.TOP_LEFT);
		textFieldInnerBox.setHgap(10);
		review.setAlignment(Pos.TOP_LEFT);


		//Instantiating a instance of JavaSQL and establish connection to database
		JavaSQL newGrade = new JavaSQL();	
		//Getting the number of courses
		int numCourses = newGrade.getCourseCount();		
		//Printing for testing purposes
		System.out.println(numCourses);	
		
		//Creating Arrays that will hold course names courses to populate combo box
		String courseNames [] = new String[numCourses];			
		//Populating courses array
		newGrade.getCourseNames(courseNames);
		
		//Populate course options combo box with contents of names array.
		for(int i = 0; i < courseNames.length; i++) {
			courseOption.getItems().addAll(courseNames[i]);		
		}	

		//Set the first list item as default for the combo box
		//courseOption.setValue(courseNames[0]);
		//Label plHldr = new Label ("Make a Selection");
		courseOption.setPromptText("Make a Selection");
		
		courseName =courseOption.getValue();
		
		//Get number of categories for this course
		//int numCategories = newGrade.getCategoryCount(courseName);
		//Test print statement
		//System.out.println(numCategories);
		
		//Declaring category names array and assign size on previous method
		//String categoryNames [] = new String[numCategories];
		
		//Populating category names array
		//newGrade.getCategoryNames(categoryNames,courseName);
		
		
		//Populate category name options combo box with contents of category names array.
		//for(int i = 0; i < categoryNames.length; i++) {
			//categoryOption.getItems().addAll(categoryNames[i]);		
		//}	

		//If user changes option, category options change as well
		courseOption.setOnAction(e->{
			try {
				categoryOption.getItems().removeAll(categoryOption.getItems());
				
				//courseOption.valueProperty().set(null);
				courseName = courseOption.getValue();
				int numCategories = newGrade.getCategoryCount(courseName);
				String categoryNames [] = new String[numCategories];
				
				//calling method to populate new category names array
				newGrade.getCategoryNames(categoryNames,courseName);
																
				//Populating combo box with new values
				for(int i = 0; i < categoryNames.length; i++) {
					categoryOption.getItems().addAll(categoryNames[i]);		
				}	
			} catch (SQLException e1) {
				e1.printStackTrace();
			}

		});

		//Getting all controls into parent nodes
		box.getChildren().addAll(courseInnerBox, categoryInnerBox,textFieldInnerBox, review);
		grades.getChildren().addAll(box);

		//Lambda will validate and capture student grade
		gradeTextField.setOnAction(e->{
			if (gradeTextField.getText().isEmpty() ||  (!isNumericDouble(gradeTextField))) { 				
				gradeTextField.clear();
				categoryOption.requestFocus();				
				textFieldWarning(gradeTextField);			
			}
			else {
				removeWarning(gradeTextField);				
				grade = Double.parseDouble(gradeTextField.getText());
				if(grade <= 0 || grade > 100.0 ) {
					gradeTextField.clear();
					categoryOption.requestFocus();
					textFieldWarning(gradeTextField);
				}
				else {
					removeWarning(gradeTextField);	
					grade = Double.parseDouble(gradeTextField.getText());
					courseName = courseOption.getValue();
					categoryName = categoryOption.getValue();

					review.setDisable(false);
				}
			}					
		});

		review.setOnAction(e-> {
			//Testing
			
			try {
				newGrade.closeConnection();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			System.out.println(courseName);
			System.out.println(categoryName);
			System.out.println(grade);			
			GradeConfirmation.confirmGrade();
		});

		//Creating Scene
		Scene gradesScene = new Scene(grades, 400, 200);
		addGradeStage.setScene(gradesScene);
		addGradeStage.show();
	}

	//ACCESSORS
	public static String getCourseName() {
		return courseName;		
	}
	public static String getCategoryName() {
		return categoryName;		
	}
	public static Double getGrade() {
		return grade;		
	}


}
