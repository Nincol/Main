package com.eclipse.nincolperez;

import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class GradeConfirmation extends FormConfirmation {
	protected static void confirmGrade() {
		Stage primaryStage = new Stage();

		//Instantiating main pane
		StackPane gradeSummary = new StackPane();
		gradeSummary.setAlignment(Pos.TOP_CENTER);


		//Instantiating inner pane
		VBox gradeContent = new VBox();
		gradeContent.setStyle("-fx-background-color: LIGHTBLUE");
		gradeContent.setAlignment(Pos.TOP_CENTER);
		gradeContent.setSpacing(10);


		//Creating other controls
		Label gradeLabel = new Label("Grade Summary");
		gradeLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, 16));
		gradeLabel.setTextFill(Color.BLUE);

		HBox confirmCourseName = new HBox();
		confirmCourseName.setSpacing(10);
		Label cName = new Label("Course Name");
		cName.setFont(Font.font("Times New Roman", FontWeight.BOLD, 14));
		Text cNameText = new Text(AddGrade.getCourseName());
		confirmCourseName.getChildren().addAll(cName, cNameText);

		HBox confirmCategoryName = new HBox();
		confirmCategoryName.setSpacing(10);
		Label catName = new Label("Category Name");
		catName.setFont(Font.font("Times New Roman", FontWeight.BOLD, 14));
		Text catNameText = new Text(AddGrade.getCategoryName());
		confirmCategoryName.getChildren().addAll(catName, catNameText);

		HBox confirmgrade = new HBox();
		confirmgrade.setSpacing(10);
		Label gradeL = new Label("Grade");
		gradeL.setFont(Font.font("Times New Roman", FontWeight.BOLD, 14));
		Text gradeText = new Text(AddGrade.getGrade().toString());
		confirmgrade.getChildren().addAll(gradeL, gradeText);

		HBox optionButtons = new HBox();
		optionButtons.setSpacing(10);
		Button editGrade = new Button("Edit");
		Button saveGrade = new Button("Save");

		//LAMBDAS
		editGrade.setOnAction(e->{
			primaryStage.close();
		});

		saveGrade.setOnAction(e->{
			try {
				JavaSQL pushGrade = new JavaSQL();
				int categoryId = pushGrade.getGradingCategoryId(AddGrade.getCategoryName());				
				pushGrade.insertGrade(AddGrade.getGrade(), categoryId);
				pushGrade.closeConnection();
				primaryStage.close();				
				AddGrade.addGradeStage.close();
				
				
				MainMenu newMain = new MainMenu();
				newMain.start(primaryStage);
				
				
			} catch (Exception e1) {
				e1.printStackTrace();
			}	
		});









		//ADDING ALL BUTTONS TO HBOX
		optionButtons.getChildren().addAll(editGrade, saveGrade);

		//ADDING ELEMENTS TO INNER VPANE
		gradeContent.getChildren().addAll(gradeLabel, confirmCourseName, confirmCategoryName, confirmgrade, optionButtons);

		//ADDING INNER PANE TO MAIN STACK PANE
		gradeSummary.getChildren().addAll(gradeContent);

		//Creating a scene
		Scene gradeScene = new Scene(gradeSummary, 400, 200);
		primaryStage.setScene(gradeScene);
		primaryStage.show();
	}	
}
