package com.eclipse.nincolperez;

import java.sql.SQLException;
import java.util.ArrayList;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class OverallGrade {
	
	protected static double overallGrade;
	protected static String courseNameForGrade;
	protected static Stage finalGradeStage = new Stage();
	
	public OverallGrade () {
		
	}
	
	public static void finalGrade() throws Exception {
		//Stage finalGradeStage = new Stage();
		
		//Instantiating main pane
		StackPane fGrade = new StackPane();
		fGrade.setAlignment(Pos.TOP_CENTER);
		
		//Instantiating inner v Box
		VBox resultInnerBox = new VBox();
		resultInnerBox.setAlignment(Pos.TOP_CENTER);
		
		//Instantiating a instance of JavaSQL and establish connection to database
		JavaSQL finalGrade = new JavaSQL();
		
		//Getting the number of courses
		int fNumCourses = finalGrade.getCourseCount();
		
		//Creating Arrays that will hold course name to populate combo boxes
		String courseNames2 [] = new String[fNumCourses];
		
		//Populating array with the courses names
		finalGrade.getCourseNames(courseNames2);
		
		//Creating controls: Combo Box that holds courses names
		ComboBox<String> fCourseOption = new ComboBox<String>();
		
		//Creating button that displays final grade based on the course name selected
		Button displayFGrade = new Button("Display Final Grade");
		//displayFGrade.setDisable(true);
		
		//DEVELOPING CONTROLS
		HBox happyBox = new HBox();
		happyBox.setSpacing(10);
		Label happyLabel = new Label("Select course name");
		happyLabel.setFont(Font.font("Times New Roman", FontWeight.BOLD, 16));
		happyBox.getChildren().addAll(happyLabel, fCourseOption);
		
		resultInnerBox.getChildren().addAll(happyBox, displayFGrade);
		resultInnerBox.setSpacing(10);
		
		fGrade.getChildren().add(resultInnerBox);
		
		//POPULATE COMBO BOXE WITH COURSES NAMES
		//Goal is to add individual course names from the names array into the combo box
		for(int i = 0; i < courseNames2.length; i++) {
			fCourseOption.getItems().addAll(courseNames2[i]);		
			}	
		//Set the first list item as default for the combo box
		//fCourseOption.setValue(courseNames2[0]);
		fCourseOption.setPromptText("Select Course");
										
		displayFGrade.setOnAction(e-> {			
			HBox fDisplaybox = new HBox();
			fDisplaybox.setSpacing(10);
			courseNameForGrade = fCourseOption.getValue();
			//Testing
			System.out.println(courseNameForGrade);		
			try {				
				overallGrade = finalGrade.getOverallGrade(courseNameForGrade);
				System.out.println(overallGrade);
				String fGradeAsString = Double.toString(overallGrade);						
				Label fGradeLable = new Label(courseNameForGrade + " Overall Grade");
				fGradeLable.setFont(Font.font("Times New Roman", FontWeight.BOLD, 14));
				Text fDisplayGrade = new Text(fGradeAsString);
				
				
				
				fDisplaybox.getChildren().addAll(fGradeLable, fDisplayGrade);
				resultInnerBox.getChildren().addAll(fDisplaybox);				
			
			} catch (SQLException e1) {
				e1.printStackTrace();
			}								
		});
		
		finalGradeStage.setOnCloseRequest(event -> {
		    System.out.println("Stage is closing");
		    try {
				finalGrade.closeConnection();
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		    // Save file
		});
		
		//Creating Scene
				Scene fGradesScene = new Scene(fGrade, 400, 200);
				finalGradeStage.setScene(fGradesScene);
				finalGradeStage.show();				
	}
}
