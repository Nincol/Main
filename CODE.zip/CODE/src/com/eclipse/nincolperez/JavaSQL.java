package com.eclipse.nincolperez;
import java.sql.*;
import java.util.ArrayList;
//import org.apache.derby.jd

public class JavaSQL {
	private Connection connection;
	
	public JavaSQL () throws Exception {
		connection = getConnection();
	}			
	/**
	 * This method establish connection to the database
	 * @return
	 * @throws Exception
	 */
	protected Connection getConnection() throws Exception {
		try {
			String url = "jdbc:sqlite:Databases/gradesuptodate.db";	
			Connection connection = DriverManager.getConnection(url);			
			System.out.println("Connected");
			return connection;
		}catch(Exception e) {
			System.out.println("Unable to connect");
			e.printStackTrace();
		}
		return null;
	}
			
	/**
	 * This method inserts data into the courses table of the database
	 * @param c
	 * @throws Exception
	 */
	protected void insertData(String cName, int numCat) throws Exception {								
			//Inserts data into the courses table
			String courses = 
					"INSERT INTO courses (courseName, gradingCategories)" + 
							"VALUES('"+cName+"','"+numCat+"')";
			Statement mystmt = connection.createStatement();
			mystmt.executeUpdate(courses);							
	}

	//This methods gets the courseId from the courses table for the corresponding new course added
	protected int getCourseId(String cName) throws SQLException {
		int id = 0;
		Statement mystmt = connection.createStatement();
		//Select the date from the specified database and table
		String sql = "SELECT courseId FROM courses WHERE courseName = '"+cName+"' ";
		//Execute the SQL statement and store it in the statement object. The results will be store in a Results set object
		ResultSet rs = mystmt.executeQuery(sql);
		while (rs.next()) {
			id = rs.getInt(1);
			
		}
		return id;		
	}

	/**
	 * Overloaded method that inserts data into the courses table of the database
	 * @param c
	 * @param catNames
	 * @param catValues
	 * @param size
	 * @throws Exception
	 * 
	 */
	protected void insertData(String[] catNames , int[] catValues, int size, int id) throws Exception {
			for(int i = 0; i < size; i++) {
				String gradingCategories = "INSERT INTO gradingcategories(categoryName, categoryValue, courses_courseId)"  + 
						"VALUES(?,?,?)";					
				PreparedStatement insertCategories = connection.prepareStatement(gradingCategories);				
				insertCategories.setString(1, catNames[i]);
				insertCategories.setInt(2, catValues[i]);
				insertCategories.setInt(3, id);
				insertCategories.executeUpdate(); 
			}		
	}	

	//Method that closes the connection
	protected void closeConnection() throws SQLException {
		connection.close();
	}

	//METHOD GETS THE COURSES COUNT
	protected int getCourseCount() throws SQLException {
		int courseCount = 0;
		Statement count = connection.createStatement();
		String ct = "SELECT COUNT(*) FROM courses";
		ResultSet cCount = count.executeQuery(ct);		
		if(cCount.next()) {
			courseCount = cCount.getInt(1);
		}		
		return courseCount;
	}

	//METHOD GETS THE GRADING CATEGORY COUNTS
	protected int getCategoryCount(String cName) throws SQLException {
		int categoryCount = 0;
		Statement count = connection.createStatement();
		String ct = "SELECT DISTINCT COUNT(*) \r\n" + 
				"FROM gradingcategories gC\r\n" + 
				"JOIN courses c \r\n" + 
				"ON c.courseId = gC.courses_courseId\r\n" + 
				"where courseName = '"+cName+"' ";
		ResultSet cCount = count.executeQuery(ct);		
		if(cCount.next()) {
			categoryCount = cCount.getInt(1);
		}		
		return categoryCount;
	}

	//METHOD GET THE COURSES NAMES
	protected String [] getCourseNames( String [] names) throws SQLException {
		String name = null;
		int i = 0;
		Statement mystmt = connection.createStatement();
		//Select the date from the specified database and table
		String sql = "SELECT courseName FROM courses";
		//Execute the SQL statement and store it in the statement object. The results will be store in a Results set object
		ResultSet rs = mystmt.executeQuery(sql);
		while (rs.next()) {
			name = rs.getString("courseName");
			names[i] = name;
			i++;
		}
		return names;
	}

	//METHOD GETS THE GRADING CATEGORIES NAMES
	protected String [] getCategoryNames( String [] names, String cName) throws SQLException {
		String name = null;
		int i = 0;
		Statement mystmt = connection.createStatement();
		//Select the date from the specified database and table
		String sql = "SELECT categoryName \r\n" + 
				"FROM gradingcategories gC\r\n" + 
				"JOIN courses c \r\n" + 
				"ON c.courseId = gC.courses_courseId\r\n" + 
				"WHERE c.courseName = '"+cName+"'";
		//Execute the SQL statement and store it in the statement object. The results will be store in a Results set object
		ResultSet rs = mystmt.executeQuery(sql);
		while (rs.next()) {
			name = rs.getString("categoryName");
			names[i] = name;
			i++;
		}
		return names;
	}

	//METHOD THAT GETS GRADING CATEGORY ID BASED ON COURSE NAME
	protected int getGradingCategoryId (String caName) throws SQLException {
		int graCaId = 0;
		Statement mystmt = connection.createStatement();
		String gradingId = "SELECT categoryId FROM gradingcategories WHERE categoryName = '"+caName+"' ";
		ResultSet rs1 = mystmt.executeQuery(gradingId);
		while (rs1.next()) {
			graCaId = rs1.getInt(1);
		}
		return graCaId;
	}

	//METHOD INSERTS GRADE IN THE APPROPIATE COURSE AND GRADING CATEGORY
	protected void insertGrade(double gr, int caId) throws SQLException {
		try {									
			//Inserts data into the courses table
			String grade = 
					"INSERT INTO grades (grade, gradingCategories_categoryid)" + 
							"VALUES('"+gr+"','"+caId+"')";
			Statement mystmt = connection.createStatement();
			mystmt.executeUpdate(grade);
		}catch(Exception e) {
			System.out.println("Unable to enter this data into database");
			e.printStackTrace();
		}
		
		closeConnection();
	}
	
	//METHOD THAT GETS FINAL GRADE BASED ON COURSE NUMBER
	protected double getOverallGrade (String cName) throws SQLException {
		double finalGrade = 0.00;
		Statement mystmt = connection.createStatement();
		String gradingId = "SELECT ROUND(sum(Category_Total),2)\r\n" + 
				"from(\r\n" + 
				"SELECT   courseName, categoryName, SUM(grade) as 'categoryTotal', COUNT(grade) as 'grades per category'\r\n" + 
				"	, SUM(grade)  / COUNT(grade) as 'currentTotalGrade', ifnull(((SUM(grade)  / COUNT(grade)) * gC.categoryValue /100), categoryValue) as \r\n" + 
				"    'Category_Total' \r\n" + 
				"FROM gradingCategories gC\r\n" + 
				"LEFT JOIN grades g\r\n" + 
				"ON g.gradingCategories_categoryId = gC.categoryId\r\n" + 
				"JOIN courses c \r\n" + 
				"ON c.courseId = gC.courses_courseId\r\n" + 
				"GROUP BY categoryName, courseId  \r\n" + 
				"having courseName = '"+cName+"') total";
				
		ResultSet rs1 = mystmt.executeQuery(gradingId);
		while (rs1.next()) {
			finalGrade = rs1.getDouble(1);
		}
		return finalGrade;			
	}					
}

