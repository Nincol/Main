package com.eclipse.nincolperez;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class FormConfirmation {
	protected static void confirmInput() {
		Stage formConfirmationStage = new Stage();

		//Instantiating main pane
		StackPane summary = new StackPane();

		//Instantiating inner pane
		VBox content = new VBox();
		content.setStyle("-fx-background-color: LIGHTBLUE");

		//Instantiating label and text
		Label label = new Label("Set up Summary");
		label.setFont(Font.font("Times New Roman", FontWeight.BOLD, 16));
		label.setTextFill(Color.BLUE);

		Text text = new Text();
		Text text1 = new Text();
		Text text2 = new Text();
		Text text3 = new Text();

		Text warningText = new Text();

		//Creating an HBox for the buttons
		HBox buttons = new HBox();
		buttons.setPadding(new Insets(20, 20, 20, 20));
		buttons.setSpacing(10);

		Button edit = new Button("Edit");
		Button save = new Button("Save");
		Button close = new Button("Close Program");
		
		edit.setDisable(true);
		save.setDisable(true);
		close.setDisable(true);

		text.setFont(Font.font("Times New Roman", 16));
		text1.setFont(Font.font("Times New Roman", FontWeight.BOLD, 16));
		text2.setFont(Font.font("Times New Roman", 16));

		warningText.setFont(Font.font("Times New Roman", FontWeight.BOLD, 16));
		warningText.setFill(Color.RED);


		//Creating a string array to store the category names and values from the Form
		String [] lines = new String [NewForm.numOfCategories];
		int i = 0;	//Loop counter

		//Instantiating a String builder
		StringBuilder fieldContent = new StringBuilder("");
		for (int j = 0; j < NewForm.categoryNames.length; j++) {			
			fieldContent.append(NewForm.categoryNames[j] + 
					"                                " + NewForm.categoryValues[j] + "\n");
		}	

		//Setting the text fields 
		text.setText("Course Name: " + NewForm.getCourseName() + 
				"\nNumber of grading categories: " + NewForm.getNumOfCategories());

		text1.setText("\n\nCategory Name         " + "Category value: ");

		text2.setText("\n" + fieldContent.toString());
		text3.setText("What would you like to do next");

		warningText.setText("Category Value must equal 100" +
				"\nPlease press Edit button to adjust category values");

		while(NewForm.valuesSum == 100) {
			edit.setDisable(false);
			save.setDisable(false);
			close.setDisable(false);
			break;
		}

		




		/**
		 * The following lambda section will provide functionality to the previous buttons.
		 */						
		//The edit button will close the current window and the user will be able to edit
		//information before saving
		//----------------------------------------------------------------------------------
		edit.setOnAction(e-> {
			formConfirmationStage.close();						
		});
		//----------------------------------------------------------------------------------
		//This will close the application without saving.The user will be given a final 
		//option to close or not
		//-------------------------------------------------------------------------------
		close.setOnAction(e-> {
			Text closingWarning = new Text("This will close the entire application" 
					+ " without saving any data\n");
			HBox yesOrNot = new HBox();
			RadioButton yes = new RadioButton("Yes");		
			RadioButton no = new RadioButton("No");
			yesOrNot.getChildren().addAll(yes,no);
			ToggleGroup group = new ToggleGroup();
			yes.setToggleGroup(group);
			no.setToggleGroup(group);
			content.getChildren().addAll(closingWarning,yesOrNot);

			yes.setOnAction(y-> {
				Platform.exit();
				System.exit(0);	
			});

			no.setOnAction(n-> {
				content.getChildren().removeAll(closingWarning,yesOrNot);
			});						
		});
		//-------------------------------------------------------------------------------------
		//This will save the initial set up information to the database
		save.setOnAction(e-> {
			try {
				JavaSQL database = new JavaSQL();
				database.insertData(NewForm.courseName, NewForm.numOfCategories);
				int courseId = database.getCourseId(NewForm.courseName);
				System.out.println(courseId);
				database.insertData(NewForm.categoryNames, NewForm.categoryValues, NewForm.numOfCategories, courseId);


				database.closeConnection();
				formConfirmationStage.close();			
				NewForm.newFormStage.close();			
				MainMenu newMain = new MainMenu();
				newMain.start(formConfirmationStage);			
				NewForm.resetAll();

			} catch (Exception e1) {
				e1.printStackTrace();
			}


		});
		//--------------------------------------------------------------------------------------
		//Adding buttons to the HBOX
		buttons.getChildren().addAll(edit,save,close);

		//Adding text content to the inner pane
		content.getChildren().addAll(label,text, text1, text2, buttons);

		//Adding everything to the main pane
		summary.getChildren().add(content);

		//Creating a scene
		Scene confirmationScene = new Scene(summary, 400, 400);
		formConfirmationStage.setScene(confirmationScene);
		formConfirmationStage.show();
	}

}






