package com.eclipse.nincolperez;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class MainMenu extends Application {
	@Override
	public void start(Stage primaryStage) throws Exception {
		//Creating a Border Pane object.This is the main layout 
		//where all the content will end up
		BorderPane mainPane = new BorderPane();

		//Creating a horizontal box object to store the buttons
		VBox bHome = new VBox(40);
		bHome.setAlignment(Pos.CENTER);					//Aligning center
		bHome.setPadding(new Insets(20, 20, 20,20));	//Creating padding

		Text scenetitle = new Text("Grades up to date");
		scenetitle.setFont(Font.font("Tahoma", FontWeight.NORMAL, 20));

		//Create the buttons
		Button newCourse = new Button("New Course");		
		Button addGrade = new Button("Add Grade");
		Button viewOverallGrade = new Button("View overall grade");
		Button closeProgram = new Button("Close Program");
		bHome.getChildren().addAll(scenetitle,newCourse,addGrade,viewOverallGrade, closeProgram);	//Adding all the buttons
		mainPane.setCenter(bHome);

		// Creating a scene, placing the main pane in it, and placing in in the stage
		Scene scene = new Scene(mainPane, 300, 350);
		primaryStage.setTitle("Grades Up to Date"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage

		//Main menu options(Switchboard)
		newCourse.setOnAction(e-> {	
			primaryStage.close();
			try {		
				NewForm.DisplayForm();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}										
		});
		
		addGrade.setOnAction(e-> {	
			primaryStage.close();
			//AddGrade newGrade = new AddGrade ();
			try {
				AddGrade.enterGrade();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		});
		
		viewOverallGrade.setOnAction(e-> {	
			primaryStage.close();
			try {
				OverallGrade.finalGrade();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}				
		});			
		closeProgram.setOnAction(e-> {
			Platform.exit();
			System.exit(0);
		});		
	}
	
	public static void main(String[] args) throws Exception {
		launch(args);									
	}	

}
